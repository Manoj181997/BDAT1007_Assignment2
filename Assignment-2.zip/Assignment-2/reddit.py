# -*- coding: utf-8 -*-
"""
Created on Sat Feb 20 00:18:37 2021

@author: Owner
"""

import requests
import praw
from pymongo import MongoClient

#Mongo client communicates with the running database instance to establish a connection.
client = MongoClient('mongodb+srv://Manoj1997:mounikaindia1997@cluster0.djdqs.mongodb.net/BDAT?retryWrites=true&w=majority')


#instantiate an authorized instance.
reddit = praw.Reddit(client_id="aZVuSsjGmUbTPA", client_secret="3WOHAKsIfs5Yiyb4SRMcNcN1KcO_NA",
                     user_agent="Manoj1997", username="Manoj_19973",
                     password="manoj0077")

post=[]

#Accessing redditor instance and obtaining submisisons instance from it.
sub= reddit.redditor("Manoj_19973").submissions.top()
for posts in sub:
    posts={ "_id": posts.id,
           "author_name":posts.author.name,
           "Text":posts.title,
           "url":posts.url}
    post.append(posts)

#Accessing the database, collection within the mongo server.
db = client['BDAT']
subreddits = db.Reddit1

#inserts multiple documents to the database.
subreddits.insert_many(post)




