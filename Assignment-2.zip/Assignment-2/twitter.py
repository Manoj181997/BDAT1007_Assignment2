# -*- coding: utf-8 -*-
"""
Created on Sat Feb 20 00:23:48 2021

@author: Owner
"""
import tweepy
from pymongo import MongoClient

client = MongoClient('mongodb+srv://Manoj1997:mounikaindia1997@cluster0.djdqs.mongodb.net/BDAT?retryWrites=true&w=majority')
db = client['BDAT']
 
consumer_key = "Fp0pW7nzkB9GNFu1JnuLDLJta"
consumer_secret = "42qQ1NVUtZcWYCLtAf8PUXtONluC2Ah4WXMNbVmDNoDuem3Zv5"
access_key = "1359049850394972161-6vMS0BqWkeCNjAGn3Wo3s4QLewbNFY"
access_secret = "tb52m7iQrdRNiMdHCZxl4ZUSoAB5Q03JGKKfisXm5DRPh"

def get_tweets(username): 
        #Creating OAuthHandler Instance.
        auth = tweepy.OAuthHandler(consumer_key, consumer_secret) 
        auth.set_access_token(access_key, access_secret)
        
        #create an API object.
        api = tweepy.API(auth)
        
        #Reading the tweets from user timeline.
        tweets = api.user_timeline(screen_name=username) 
        user = api.get_user(username)
        tweets_text = [tweet.text for tweet in tweets] # Extracts the text content of the tweets.
        
        
        #Storing in the database.
        post=[] 
        for i in tweets_text:
            posts={
                'id':user.id,
                'name':user.name,
                'screen_name':user.screen_name,
                'image_url':user.profile_image_url,
                'text':i,
                }
            post.append(posts)
        
        print(post)    
        twitter = db.Twitter
        sub_id = twitter.insert_many(post)

if __name__ == '__main__': 
    #Type the username who's tweets are to be extracted and stored in the database.
	get_tweets("Manoj77114266") 
    
    