# -*- coding: utf-8 -*-
"""
Created on Sat Feb 20 00:26:21 2021

@author: Owner
"""

from flask import Flask,render_template,request
#creation of Flask Application object. Contains info about the application and object methods.
import praw
import tweepy
from pymongo import MongoClient

app = Flask(__name__)

client = MongoClient('mongodb+srv://Manoj1997:mounikaindia1997@cluster0.djdqs.mongodb.net/BDAT?retryWrites=true&w=majority')

db = client['BDAT']

reddit = praw.Reddit(client_id="aZVuSsjGmUbTPA", client_secret="3WOHAKsIfs5Yiyb4SRMcNcN1KcO_NA",
                     user_agent="Manoj1997", username="Manoj_19973",
                     password="manoj0077")

consumer_key = "Fp0pW7nzkB9GNFu1JnuLDLJta"
consumer_secret = "42qQ1NVUtZcWYCLtAf8PUXtONluC2Ah4WXMNbVmDNoDuem3Zv5"
access_key = "1359049850394972161-6vMS0BqWkeCNjAGn3Wo3s4QLewbNFY"
access_secret = "tb52m7iQrdRNiMdHCZxl4ZUSoAB5Q03JGKKfisXm5DRPh"


@app.route('/')
def hello():
    if request.args:
        post = request.args.get('post')
        url = request.args.get('url')
        sub = reddit.subreddit('u_Manoj_19973')
        postr = sub.submit(post,url = url)
        result = True
        subreddit = {
    "_id":sub.id,        
    "author_name": "Manoj_19973",
    "Text": post,
    "url": url
        }
        subreddits = db.Reddit1
        sub_id = subreddits.insert_one(subreddit)
    else:
        result = False
    return render_template('index.html',res = result)

@app.route('/tweet')
def twit():
    if request.args:
        tweet = request.args.get('tweet')
        auth = tweepy.OAuthHandler(consumer_key, consumer_secret) 
  
        # authentication of access token and secret 
        auth.set_access_token(access_key, access_secret) 
        api = tweepy.API(auth) 
  
        # update the status 
        api.update_status(status =tweet)
        
        user2 = api.get_user("Manoj77114266")
        twit = {
                 'id':user2.status.id,
                'name':user2.name,
                'screen_name':user2.screen_name,
                'image_url':user2.profile_image_url,
                'text':tweet,            
                 
                }
        twitter = db.Twitter
        twitter.insert_one(twit)
        result = True
    else:
        result = False
    return render_template('index.html',res = result)

if __name__ == '__main__':
   #Call the method that runs the application server. 
    app.run()
